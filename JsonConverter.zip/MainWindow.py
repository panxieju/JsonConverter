import json

from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QMainWindow

from Ui.JsonConverterUi import Ui_MainWindow
from utils.formater import jsonFormater


class MainWindow(QMainWindow,Ui_MainWindow):

    def __init__(self):
        super(MainWindow, self).__init__(parent=None)
        self.clipBoard = QtWidgets.QApplication.clipboard()
        self.setupUi(self)

        self.defineButtons()
        self.textEdit.textChanged.connect(self.onTextChanged)

    def defineButtons(self):
        self.setButtons(False)
        self.actionClear.setEnabled(False)
        self.actionCopy.setEnabled(False)
        self.actionClear.triggered.connect(self.clear)
        self.actionPaste.triggered.connect(self.paste)
        self.actionFormat.triggered.connect(self.format)

    def clear(self):
        self.textEdit.clear()
        self.setButtons(False)
        self.statusbar.clearMessage()
        self.actionClear.setEnabled(False)
        self.actionCopy.setEnabled(False)

    def paste(self):
        text = self.clipBoard.text()
        self.textEdit.setText(text)
        self.check_input(text)

    def onTextChanged(self):
        text = self.textEdit.toPlainText()
        self.check_input(text)

    def check_input(self, text):
        self.actionClear.setEnabled(True)
        self.actionCopy.setEnabled(True)
        try:
            self.data = json.loads(text)
            self.setButtons(True)
        except:
            self.statusbar.showMessage("不是有效的JSON数据,请检查")
            self.setButtons(False)

    def setButtons(self, ena):
        self.actionFormat.setEnabled(ena)
        self.actionJava.setEnabled(ena)
        self.actionKotlin.setEnabled(ena)
        self.actionGolang.setEnabled(ena)

    def format(self):
        text = self.textEdit.toPlainText()
        result = jsonFormater(text)
        self.textEdit.setText(result)





