from functools import reduce

from utils.common import hump


def generateSetterAndGetter(key, type, inden=0):
    assert isinstance(key, str)
    setFunctionName = 'set%s' % hump(key)
    getFunctionName = 'get%s' % hump(key)
    if type == 'boolean':
        if key[:2] != 'is':
            setFunctionName = 'set%s' % hump(key)
            getFunctionName = 'is%s' % hump(key)
        else:
            setFunctionName = 'set%s' % hump(key[2:])
            getFunctionName = key

    fun = '''
public void {0}({2} {1})$1
    this.{1} = {1};
$2

public {2} {3}()$1
    return this.{1};
$2
'''.format(setFunctionName, key, type, getFunctionName).replace('$1', '{').replace('$2', '}')
    ret = []
    for line in fun.split('\n'):
        ret.append('\t' * (inden) + line)
    return reduce(lambda x, y: '{}\n{}'.format(x, y), ret)


def generateJavaClass(data, key='DEMO', inden=0):
    assert isinstance(data, dict)
    classInden = inden
    methodInden = inden + 1
    result = ''
    if inden == 0:
        result += '''
/**
Created By JsonConverter
Copyright@Nexttec Inc, 2020.
*/

public class DemoClass$0
    /**
    {}
    */
'''.format(data).replace('$0', '{')
    else:
        result += '\n'
        result += '\t' * classInden + 'public class {0}$0\n'.format(hump(key)).replace('$0', '{')
        result += '\t' * methodInden + '/**\n'
        result += '\t' * methodInden + '{}\n'.format(data)
        result += '\t' * methodInden + '*/\n\n'
    innerClass = {}
    setterAndGetters = []
    lastIndex = len(data.keys()) - 1
    keys = list(data.keys())
    keys.sort()
    for key in keys:
        value = data[key]
        result += '\t' * methodInden
        if isinstance(value, str):
            result += 'private String ' + key + ';'
            setterAndGetters.append(generateSetterAndGetter(key, "String", methodInden))
        elif isinstance(value, float):
            result += "private float " + key + ';'
            setterAndGetters.append(generateSetterAndGetter(key, "float", methodInden))
        elif isinstance(value, bool):
            result += "private boolean " + key + ';'
            setterAndGetters.append(generateSetterAndGetter(key, "boolean", methodInden))
        elif isinstance(value, int):
            result += "private int " + key + ';'
            setterAndGetters.append(generateSetterAndGetter(key, "int", methodInden))
        elif isinstance(value, bytes):
            result += "private byte[] " + key + ';'
            setterAndGetters.append(generateSetterAndGetter(key, "byte[]", methodInden))
        elif isinstance(value, dict):
            innerClass[key] = value
            result += "private %s " % hump(key) + key + ';'
            setterAndGetters.append(generateSetterAndGetter(key, hump(key), methodInden))
        elif isinstance(value, list):
            types = set()
            for item in value:
                types.add(type(item))
            if len(types) != 1:
                return key + "对应的数据类型不一致", 1
            value = value[0]
            if isinstance(value, str):
                result += "private String[] " + key + ';'
                setterAndGetters.append(generateSetterAndGetter(key, "String[]", methodInden))
            elif isinstance(value, float):
                result += "private float[]" + key + ';'
                setterAndGetters.append(generateSetterAndGetter(key, "float[]", methodInden))
            elif isinstance(value, bool):
                result += "private boolean[] " + key + ';'
                setterAndGetters.append(generateSetterAndGetter(key, "boolean[]", methodInden))
            elif isinstance(value, int):
                result += "private int[] " + key + ';'
                setterAndGetters.append(generateSetterAndGetter(key, "int[]", methodInden))
            elif isinstance(value, bytes):
                result += "private byte[] " + key + ';'
                setterAndGetters.append(generateSetterAndGetter(key, "byte[]", methodInden))
            elif isinstance(value, dict):
                innerClass[key] = value
                result += "private List<%s> " % hump(key) + key + ';'
                setterAndGetters.append(generateSetterAndGetter(key, "List<%s>" % hump(key), methodInden))
        result += '\n'

    if setterAndGetters:
        for item in setterAndGetters:
            result += item
        # result = result.strip()

    if innerClass:
        for k, v in innerClass.items():
            ret, err = generateJavaClass(v, k, inden + 1)
            if err == 0:
                result += ret

    result += '\n' + '\t' * classInden + '}'
    return result, 0


if __name__ == '__main__':
    person = {'name': 'centros', 'age': 40, 'isMarried': True, 'height': 172.0, 'lucky': [23, 32, 19, 79],
              "location": {"city": {"district": "panyu", "town": "shilou"}, "province": "guangdong"},"history":[{"time":123213123,"post":"hello"},{"time":43242231,"post":"byebye"}]}
    ret, err = generateJavaClass(person)
    print(ret)
    print(err)
