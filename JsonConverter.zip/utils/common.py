

def hump(value):
    assert isinstance(value, str)
    return value[0].upper()+ value[1:]




